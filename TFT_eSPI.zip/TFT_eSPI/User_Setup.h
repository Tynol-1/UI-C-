/***************************************************************************************
 * User_Setup.h for 4.0" ST7796S TFT (480x320) + XPT2046 Touch
 * MCU: ESP32 (custom pins)
 ***************************************************************************************/

// ======= TFT DRIVER =======
#define ST7796_DRIVER        // 480x320 TFT with ST7796S controller

// ======= PIN MAPPING =======
// SPI interface pins
#define TFT_SCLK   18        // SPI Clock
#define TFT_MOSI   19        // SPI MOSI
#define TFT_MISO   16        // SPI MISO (not always needed for TFT)

// TFT control pins
#define TFT_CS     17        // Chip select
#define TFT_DC     20        // Data/Command
#define TFT_RST    21        // Reset (-1 if tied to 3V3)

// TFT backlight (if controlled by GPIO, else -1)
#define TFT_BL     -1        // -1 = not connected, drive BL directly from VCC

// ======= TOUCH CONTROLLER (XPT2046) =======
#define TOUCH_CS   15        // Chip select for touch
// #define TOUCH_IRQ -1       // IRQ not used

// --- load the built-in 8×6 GLCD font (TextFont = 1) ---
#define LOAD_GLCD

// (optional but recommended if you use examples that pick other fonts)
#define LOAD_FONT2   // small 16-pixel
#define LOAD_FONT4   // medium 26-pixel
#define LOAD_FONT6   // large 48-pixel
#define LOAD_FONT7   // 7-segment 48-pixel
#define LOAD_FONT8   // large 75-pixel
#define LOAD_GFXFF   // Adafruit_GFX free fonts via setFreeFont()
#define SMOOTH_FONT // anti-aliased font

// ======= SPI FREQUENCIES =======
#define SPI_FREQUENCY        80000000   // 40 MHz for fast screen updates
#define SPI_READ_FREQUENCY   20000000   // 16 MHz for reading TFT
#define SPI_TOUCH_FREQUENCY   2500000   // 2.5 MHz for XPT2046
#define SUPPORT_TRANSACTIONS
// ======= COLOR ORDER / INVERSION =======
#define TFT_RGB_ORDER TFT_BGR
// If display looks inverted, try toggling one of these:
// #define TFT_INVERSION_ON
// #define TFT_INVERSION_OFF